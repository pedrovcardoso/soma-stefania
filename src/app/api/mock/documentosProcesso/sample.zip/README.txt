Shrek toothpaste cap by buzera on Thingiverse: https://www.thingiverse.com/thing:5837184

Summary:
shrek toothpaste cap